"""Provider-neutral async I/O port; Rust admits and finalizes every attempt."""
import asyncio
import os
from typing import Protocol

from . import _native


class ProviderFailure(Exception):
    def __init__(self, code):
        self.code = code
        super().__init__(code)


class TextProvider(Protocol):
    name: str

    async def generate(self, text: str, model: str) -> str: ...


class AnthropicProvider:
    name = "anthropic"

    def __init__(self, api_key: str):
        if not api_key.strip():
            raise ValueError("Set ANTHROPIC_API_KEY intentionally in your runtime environment.")
        self._api_key = api_key

    async def generate(self, text: str, model: str) -> str:
        import anthropic

        try:
            async with anthropic.AsyncAnthropic(
                api_key=self._api_key, base_url="https://api.anthropic.com",
                timeout=45.0, max_retries=0,
            ) as client:
                async with asyncio.timeout(60):
                    response = await client.messages.create(
                        model=model, max_tokens=2048,
                        messages=[{"role": "user", "content": text}],
                    )
            if response.stop_reason == "max_tokens":
                raise ProviderFailure("output_limit")
            if response.stop_reason == "refusal":
                raise ProviderFailure("refusal")
            if response.stop_reason != "end_turn" or not isinstance(response.content, list):
                raise ProviderFailure("malformed_response")
            parts = []
            for block in response.content:
                if block.type != "text" or not isinstance(block.text, str):
                    raise ProviderFailure("malformed_response")
                parts.append(block.text)
            output = "\n".join(parts)
            if not output.strip():
                raise ProviderFailure("empty_response")
            return output.replace(self._api_key, "[redacted]")
        except ProviderFailure:
            raise
        except anthropic.AuthenticationError:
            raise ProviderFailure("authentication") from None
        except anthropic.RateLimitError:
            raise ProviderFailure("rate_limit") from None
        except (TimeoutError, anthropic.APITimeoutError):
            raise ProviderFailure("timeout") from None
        except anthropic.APIConnectionError:
            raise ProviderFailure("network") from None
        except (AttributeError, TypeError):
            raise ProviderFailure("malformed_response") from None
        except Exception:
            raise ProviderFailure("provider_error") from None


def record(row):
    result = dict(zip(("run_id", "input", "provider", "model", "deadline_unix_ms", "output", "error"), row, strict=True))
    result["schema_version"] = 1
    result["quality"] = "unverified"
    return result


def configured_provider(model):
    if not model or not model.strip():
        raise ValueError("Supply an explicit --model available to your Anthropic account.")
    return AnthropicProvider(os.environ.get("ANTHROPIC_API_KEY", ""))


async def execute_text(database, task, agent, text, model, provider: TextProvider):
    row = _native.start_execution(database, task, agent, text, provider.name, model)
    return await finish_text(database, row, provider)


async def finish_text(database, row, provider: TextProvider):
    """Perform only async provider I/O for an already Rust-admitted execution."""
    run = row[0]
    try:
        async with asyncio.timeout(65):
            output = await provider.generate(row[1], row[3])
        if not isinstance(output, str):
            raise ProviderFailure("malformed_response")
        if not output.strip():
            raise ProviderFailure("empty_response")
        if len(output.encode("utf-8")) > 1_000_000:
            raise ProviderFailure("malformed_response")
    except (asyncio.CancelledError, KeyboardInterrupt):
        _native.finish_execution(database, run, None, "interrupted")
        raise
    except TimeoutError:
        return record(_native.finish_execution(database, run, None, "timeout"))
    except ProviderFailure as exc:
        return record(_native.finish_execution(database, run, None, exc.code))
    except Exception:
        return record(_native.finish_execution(database, run, None, "provider_error"))
    return record(_native.finish_execution(database, run, output, None))
